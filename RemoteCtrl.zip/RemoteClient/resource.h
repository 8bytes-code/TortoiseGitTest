﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RemoteClient.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTECLIENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU_RCLICK                 131
#define IDD_DLG_STATUS                  132
#define IDD_DLG_WATCH                   134
#define IDC_BTN_TEST                    1000
#define IDC_EDIT_PORT                   1001
#define IDC_IPADDRESS_SERV              1002
#define IDC_TREE_DIR                    1003
#define IDC_LIST_FILE                   1004
#define IDC_BTN_FILEINFO                1005
#define IDC_EDIT_INFO                   1006
#define IDC_BTN_STRAT_WATCH             1007
#define IDC_WATCH                       1008
#define ID_32780                        32780
#define ID_32781                        32781
#define ID_32782                        32782
#define ID_DOWNLOAD_FILE                32783
#define ID_32784                        32784
#define ID_DELETE_FILE                  32785
#define ID_OPEN_FILE                    32786

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
